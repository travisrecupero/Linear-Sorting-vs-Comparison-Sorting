package p1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Driver {

	
		
	public static void writeValue(int min, int max, int numOfLines, PrintWriter writer, File textFile) {
		for(int i = 0; i < numOfLines; i++) {
			int writeVal = ThreadLocalRandom.current().nextInt(min, max + 1);
			writer.println(writeVal);
		}
		writer.flush();
	}
	
	public static void main(String[] args) throws FileNotFoundException {
		File textFile = new File("output.txt");
		PrintWriter writer = new PrintWriter(textFile);
		Scanner input = new Scanner(System.in);
		
		System.out.println("Please enter minimum number: ");
		int min = input.nextInt();

		System.out.println("Please enter maximum number: ");
		int max = input.nextInt();
		
		System.out.println("Please enter the amount of line numbers: ");
		int numOfLines = input.nextInt();
		
		if(min > max) {
			System.out.println("Min must be less than max!");
			System.exit(0);
		}
		System.out.println(min + " " + max + " " + numOfLines);
		writeValue(min, max, numOfLines,writer, textFile);
	}

}
